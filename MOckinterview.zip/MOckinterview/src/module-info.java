/**
 * 
 */
/**
 * @author Asus
 *
 */
module MOckinterview {
}