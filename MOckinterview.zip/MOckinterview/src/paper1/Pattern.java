package paper1;

import java.util.ArrayList;
import java.util.HashSet;

public class Pattern {

	public static void main(String[] args) {
	for (int i = 0; i <=5; i++) {
		for (int j = 0; j <=i; j++) {
			System.out.print(j);
			
			}
			
			for (int j = 5; j >=i; j--) {
				System.out.print("#");
			}
			System.out.println();
		}
		
	}
	}
	
	
	
	
