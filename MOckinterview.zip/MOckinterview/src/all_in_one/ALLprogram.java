package all_in_one;


	import java.util.HashSet;
	import java.util.Scanner;

	public class ALLprogram {
		int no ;
		int no1;
		String name;
		public void amst(int no) {
			this.no=no;
			int org=no;
			int rem;
			int cubbing=0;
			while(no!=0) {
				rem=no%10;
				cubbing=cubbing+(rem*rem*rem);
				no=no/10;
			}
			if(cubbing==org) {
				System.out.println("it is amstron");
			}
			else {
				System.out.println("not..");
			}
		}
		public void revers (int no) {
			int revers=0;
			
			int rem;
			while(no!=0) {
				rem= no%10;
				revers=revers*10+rem;
				no=no/10;
				
			}
			System.out.println(revers);
		}
		public void fibonaccieseries() {
		int a=1;
		int b=2;
			int sum=0;
			for (int i = 0; i <=10; i++) {
				sum=a+b;
				a=b;
				b=sum;
			
				System.out.print(sum+",");
			}
			System.out.println();
		}
		
		public void alleven() {
			System.out.println("even number>>>>>");
			for (int i = 0; i <=1000; i++) {
				if(i%2==0) {
					System.out.print(i+",");
				}
			
			}
		}
		public void allodd() {
			System.out.println("odd number>>>>>>");
			for (int i = 0; i <=1000; i++) {
				if(i%2!=0) {
					System.out.print(i+",");
				}
			}System.out.println();
		}
		public void sortarry_asscending() {
			System.out.println();
			Scanner sc = new Scanner (System.in);
			System.out.println("enter 5 number which u want to sort");
		int a[]= new int [5];
		for (int i = 0; i <=a.length-1; i++) {
			a[i]=sc.nextInt();
			
			
			}
		int temp=0;
	for (int i = 0; i <=a.length-1; i++) {
		for (int j = i+1; j <=a.length-1; j++) {
			if(a[i]>a[j]) {
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			
		}System.out.println("sorted arrayy "+a[i]);
	}
		
		}
		public void checkodd_even(int no) {
			System.out.println();
			this.no=no;
			if(no%2!=0) {
				System.out.println(no+": it is a odd number");
			}else {
				System.out.println(no+": it is even  number");
			}
			
		}
		public void primenumber(int no) {
			System.out.println();
			this.no=no;
			int count=0;
			for (int i = 2; i <=no-1; i++) {
				if(no%i==0) {
					count++;
				}
				
			}
			if(count==0) {
				System.out.println("its a prime number");
			}
			
			else {
				System.out.println("not a prime");
			}
			
		}
		public void reverstring(String name) {
			 
			for (int i = name.length()-1; i >=0; i--) {
				System.out.print(name.charAt(i)+",");
			}
		}
		public void max_number_of_array() {
			
			Scanner sc = new Scanner(System.in);
			System.out.println("enter a 5 numbers");
			int arr[]= new int [5];
			for (int i = 0; i <=arr.length-1; i++) {
				arr[i]=sc.nextInt();
			}
			int max=arr[1];
			for (int i = 0; i <=arr.length-1; i++) {
				for (int j = 0; j <=arr.length-1; j++) {
					if(max<arr[i]) {
						max=arr[i];
						
					}
				}
				
			}
			System.out.println("max value of the array"+max);
			
		}
		
		public void min_array() {
			Scanner sc = new Scanner(System.in);
			System.out.println("enter a 5 numbers");
			int arr[]= new int [5];
			for (int i = 0; i <=arr.length-1; i++) {
				arr[i]=sc.nextInt();
			}
			int min=arr[1];
			for (int i = 0; i <=arr.length-1; i++) {
				for (int j = 0; j <=arr.length-1; j++) {
					if(min>arr[i]) {
						min=arr[i];
						
						
					}
				}
				
			}
			System.out.println(min);
			
		}
		public void vowels_constants(String name) {
			
		for (int i = 0; i <=name.length()-1; i++) {
			if(name.charAt(i)=='a'||name.charAt(i)=='e'||name.charAt(i)=='i'||name.charAt(i)=='o'||name.charAt(i)=='u') {
				System.out.println(name.charAt(i)+": is an vowel");
			}else {
				//System.out.println(name.charAt(i)+": constatas");
			}
			
			
		}
		}
		public void sort_in_descending() {
			
			Scanner sc = new Scanner(System.in);
			System.out.println("enter 5 elements");
			int arr[]= new int[5];
		for (int i = 0; i <=arr.length-1; i++) {
			arr[i]=sc.nextInt();
		}
		int temp=0;
		for (int i = 0; i <=arr.length-1; i++) {
			for (int j = i+1; j <=arr.length-1; j++) {
				if(arr[i]<arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
					
				}
			}
			System.out.println(arr[i]);
		}
		
		}
		public void count_first50_prime() {
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>first 50 prime numbers>>>>>>>>>>>>>>>>>");
			int count=0;
			
			for (int i = 2; i <=500; i++) {
				int temp=0;
				for (int j = 2; j <=i-1; j++) {
					if(i%j==0) {
						temp++;
						
					}
					
					
				}
				if(temp==0 && count<50) {
					count++;
					System.out.println(count+")"+i);
				}
				
			}
			
			
		}

		public void dupalicateremove(String name) {
			HashSet <Character> hs = new HashSet<>();
			for (int i = 0; i <=name.length()-1; i++) {
				char a = name.charAt(i);
				
				hs.add(a);
				
			}
			System.out.println(hs);
			
		}
		public void panlidramnumber(int no) {
			int org=no;
			int rem;
			int revers=0;
			while(no!=0) {
				rem=no%10;
				revers=revers+rem;
				no=no/10;
				
			}
			if(org==revers) {
				System.out.println(revers+"it a palindramnumber");
			}
			
		}
		
		public void factorial(int no) {
			int fact=1;
			int sum=0;
			for (int i = 1; i <=no; i++) {
			fact=fact*i;
				
			}
			sum=sum+fact;

			System.out.println("factorial"+sum);
		}
		public void sum_of_allintege(int no) {
			int sum=0;
			int rem;
			while(no!=0) {
				rem=no%10;
				
				sum=sum+rem;
				no=no/10;
			}
			System.out.println("sum of integer"+sum);
		}
		public void distnict(String name) {
			int count=0;
			for (int i = 0; i <=name.length()-1; i++) {
				count++;
			}
			System.out.println(count);
		}
		public void removewhitespace(String name) {
			String name1 = name;
			
			name1= name1.replaceAll("\\s", "");
			System.out.println(name1);
			
		}
		public static void main(String[] args) {
			ALLprogram am= new ALLprogram();
		am.factorial(4);
			am.dupalicateremove("thekiranacademypune");
			am.count_first50_prime();
			am.amst(153);
			am.revers(123);
			am.fibonaccieseries();
			am.allodd();
			am.alleven();
			am.primenumber(4);
			//am.max_number_of_array();
			am.reverstring("kiranpatildhondge");
			am.checkodd_even(2);
		 	//am.sortarry_asscending();
			//am.min_array();
			//am.sort_in_descending();
			am.vowels_constants("thekiranacademypune");
			am.sum_of_allintege(18181);
			am.distnict("thekiranacademypune");
		am.removewhitespace("the kiran academy karvenagar pune");
		
	}

}
